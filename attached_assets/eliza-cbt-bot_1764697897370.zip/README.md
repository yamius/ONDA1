# ELIZA + CBT flows (Woebot-style) demo

Suggested structure (under `src/` in your React app):

- `src/bot/eliza.ts` — extended ELIZA logic (pattern-based, English only).
- `src/bot/flowsTypes.ts` — TypeScript types for CBT-like flows.
- `src/bot/flowsValidation.ts` — validator for flows JSON.
- `src/bot/flows.json` — content: anxiety, panic, body, fear, pain, loneliness, anger flows.
- `src/bot/flowsIndex.ts` — imports JSON, validates and exports `flows`.
- `src/bot/conversationEngine.ts` — engine that routes between ELIZA mode and flow mode.
- `src/bot/useChatEngine.ts` — React hook example for integrating with your chat UI.

In your chat component you can:
- call `sendUserText(text)` on user message,
- render `messages`,
- if `msg.ui?.type === "buttons"` — show buttons and call `sendUserValue(option.value)` on click,
- if `msg.ui?.type === "scale"` — show slider and call `sendUserValue(value)`,
- call `startFlow("anxiety_basic")` (or another flow id) from a button/menu to launch a guided CBT-style exercise.
