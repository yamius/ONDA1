import Foundation
import HealthKit

final class WorkoutManager: NSObject, ObservableObject {
    static let shared = WorkoutManager()

    let healthStore = HKHealthStore()

    @Published private(set) var currentHeartRate: Double = 0
    @Published private(set) var isWorkoutRunning: Bool = false

    private var workoutSession: HKWorkoutSession?
    private var workoutBuilder: HKLiveWorkoutBuilder?

    private override init() {
        super.init()
    }

    // MARK: - HealthKit

    func requestAuthorization() {
        guard HKHealthStore.isHealthDataAvailable() else { return }

        let typesToShare: Set = [HKObjectType.workoutType()]
        let typesToRead: Set = [
            HKObjectType.quantityType(forIdentifier: .heartRate)!
        ]

        healthStore.requestAuthorization(toShare: typesToShare,
                                         read: typesToRead) { success, error in
            if let error = error {
                print("HealthKit auth error:", error)
            } else {
                print("HealthKit auth success:", success)
            }
        }
    }

    // MARK: - Workout control

    func startWorkout() {
        guard workoutSession == nil else { return }

        let config = HKWorkoutConfiguration()
        config.activityType = .mindAndBody
        config.locationType = .indoor

        do {
            let session = try HKWorkoutSession(healthStore: healthStore,
                                               configuration: config)
            let builder = session.associatedWorkoutBuilder()

            session.delegate = self
            builder.delegate = self

            builder.dataSource = HKLiveWorkoutDataSource(healthStore: healthStore,
                                                         workoutConfiguration: config)

            let startDate = Date()

            session.startActivity(with: startDate)
            builder.beginCollection(withStart: startDate) { [weak self] success, error in
                DispatchQueue.main.async {
                    self?.isWorkoutRunning = true
                }
                if let error = error {
                    print("beginCollection error:", error)
                }
            }

            self.workoutSession = session
            self.workoutBuilder = builder
        } catch {
            print("Failed to start workout session:", error)
        }
    }

    func stopWorkout() {
        guard let session = workoutSession,
              let builder = workoutBuilder else { return }

        let endDate = Date()

        session.stopActivity(with: endDate)
        session.end()

        builder.endCollection(withEnd: endDate) { [weak self] success, error in
            builder.finishWorkout { workout, error in
                DispatchQueue.main.async {
                    self?.isWorkoutRunning = false
                    self?.currentHeartRate = 0
                    self?.workoutSession = nil
                    self?.workoutBuilder = nil
                }
                if let error = error {
                    print("finishWorkout error:", error)
                }
            }
        }
    }
}

// MARK: - HKWorkoutSessionDelegate & HKLiveWorkoutBuilderDelegate

extension WorkoutManager: HKWorkoutSessionDelegate, HKLiveWorkoutBuilderDelegate {

    func workoutSession(_ workoutSession: HKWorkoutSession,
                        didChangeTo toState: HKWorkoutSessionState,
                        from fromState: HKWorkoutSessionState,
                        date: Date) {
        print("Workout state changed from \(fromState.rawValue) to \(toState.rawValue)")
    }

    func workoutSession(_ workoutSession: HKWorkoutSession,
                        didFailWithError error: Error) {
        print("Workout session failed:", error)
    }

    func workoutBuilder(_ workoutBuilder: HKLiveWorkoutBuilder,
                        didCollectDataOf collectedTypes: Set<HKSampleType>) {

        for sampleType in collectedTypes {
            guard let quantityType = sampleType as? HKQuantityType else { continue }

            if quantityType == HKObjectType.quantityType(forIdentifier: .heartRate),
               let statistics = workoutBuilder.statistics(for: quantityType) {

                let unit = HKUnit.count().unitDivided(by: HKUnit.minute())
                if let value = statistics.mostRecentQuantity()?.doubleValue(for: unit) {
                    DispatchQueue.main.async {
                        self.currentHeartRate = value
                    }
                }
            }
        }
    }

    func workoutBuilderDidCollectEvent(_ workoutBuilder: HKLiveWorkoutBuilder) {
        // Метод обязателен, но нам здесь не нужен
    }
}
