import SwiftUI

@main
struct PracticeWatchApp: App {
    @StateObject private var workoutManager = WorkoutManager.shared
    @StateObject private var connectivity = WatchSessionManager.shared

    init() {
        WatchSessionManager.shared.activate()
        WorkoutManager.shared.requestAuthorization()
    }

    var body: some Scene {
        WindowGroup {
            WatchContentView()
                .environmentObject(workoutManager)
        }
    }
}
