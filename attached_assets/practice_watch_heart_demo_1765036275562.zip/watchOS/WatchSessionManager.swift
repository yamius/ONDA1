import Foundation
import WatchConnectivity

final class WatchSessionManager: NSObject, ObservableObject, WCSessionDelegate {
    static let shared = WatchSessionManager()

    private var lastHeartbeatDate: Date?
    private var heartbeatMonitorTimer: Timer?
    private let timeout: TimeInterval = 5.0  // секунд без пинга до авто-стопа

    private override init() {
        super.init()
    }

    func activate() {
        guard WCSession.isSupported() else { return }
        let session = WCSession.default
        session.delegate = self
        session.activate()
    }

    // MARK: - WCSessionDelegate

    func session(_ session: WCSession,
                 activationDidCompleteWith activationState: WCSessionActivationState,
                 error: Error?) {
        if let error = error {
            print("Watch WCSession activation error:", error)
        } else {
            print("Watch WCSession activated:", activationState.rawValue)
        }
    }

    func session(_ session: WCSession,
                 didReceiveMessage message: [String : Any]) {
        guard let type = message["type"] as? String else { return }

        switch type {
        case "startWorkout":
            startWorkoutWithMonitor()
        case "stopWorkout":
            stopWorkoutAndMonitor()
        case "heartbeat":
            lastHeartbeatDate = Date()
        default:
            break
        }
    }

    // MARK: - Heartbeat monitoring

    private func startWorkoutWithMonitor() {
        WorkoutManager.shared.startWorkout()

        lastHeartbeatDate = Date()
        heartbeatMonitorTimer?.invalidate()
        heartbeatMonitorTimer = Timer.scheduledTimer(withTimeInterval: 2.0,
                                                     repeats: true) { [weak self] _ in
            self?.checkHeartbeat()
        }
        if let timer = heartbeatMonitorTimer {
            RunLoop.main.add(timer, forMode: .common)
        }
    }

    private func stopWorkoutAndMonitor() {
        heartbeatMonitorTimer?.invalidate()
        heartbeatMonitorTimer = nil
        WorkoutManager.shared.stopWorkout()
    }

    private func checkHeartbeat() {
        guard let last = lastHeartbeatDate else { return }
        let delta = Date().timeIntervalSince(last)
        if delta > timeout {
            print("Heartbeat timed out (\(delta)s) – stopping workout")
            stopWorkoutAndMonitor()
        }
    }
}
