import SwiftUI

struct WatchContentView: View {
    @EnvironmentObject var workoutManager: WorkoutManager

    var body: some View {
        VStack(spacing: 8) {
            Text("Практика")
                .font(.headline)

            Text(workoutManager.isWorkoutRunning ? "Workout активен" : "Workout выключен")
                .font(.footnote)
                .foregroundColor(.secondary)

            Text("\(Int(workoutManager.currentHeartRate))")
                .font(.system(size: 40, weight: .medium, design: .rounded))

            Text("BPM")
                .font(.caption)

            Spacer()
        }
        .padding()
    }
}
