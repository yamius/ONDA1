# Demo: высокочастотный пульс на Apple&nbsp;Watch только во время практики

Этот пример показывает, как:

- запустить `HKWorkoutSession` + `HKLiveWorkoutBuilder` на Apple&nbsp;Watch, чтобы получить быстрый стрим пульса;
- управлять этой сессией с iOS‑приложения (когда практика включена);
- автоматически выключать workout, если практика остановилась или iPhone пропал/приложение свернули.

Логика такая:

- iOS‑приложение знает состояние практики (идёт / остановлена).
- Пока практика идёт, оно:
    - один раз отправляет на часы команду **`startWorkout`**;
    - раз в 1 секунду шлёт «heartbeat» — сообщение `{"type": "heartbeat"}`.
- Когда практика заканчивается (кнопка стоп или приложение уходит в фон) — шлём **`stopWorkout`** и прекращаем heartbeats.
- Часы:
    - при `startWorkout` запускают `HKWorkoutSession` + `HKLiveWorkoutBuilder`;
    - при каждом `heartbeat` запоминают время последнего пинга;
    - таймер раз в 2 секунды проверяет, давно ли не было пингов; если больше 5 секунд — останавливает workout.

Таким образом, **высокочастотный режим датчика включён только пока практика жива на телефоне**.

## Структура архива

```text
practice_watch_heart_demo/
├─ README.md
├─ iOS/
│  ├─ PracticeApp.swift
│  ├─ ContentView.swift
│  ├─ PracticeController.swift
│  └─ PhoneSessionManager.swift
└─ watchOS/
   ├─ PracticeWatchApp.swift
   ├─ WatchContentView.swift
   ├─ WorkoutManager.swift
   └─ WatchSessionManager.swift
```

## Краткое описание файлов

### iOS

- **PracticeApp.swift** — SwiftUI‑точка входа. Поднимает `PracticeController` и `PhoneSessionManager`,
  слушает `scenePhase` и при уходе приложения в фон автоматически останавливает практику
  (а значит, и workout на часах).
- **ContentView.swift** — простейший экран с кнопкой «Начать/Остановить практику» и текстовым статусом.
  В реальном проекте сюда можно встроить твой текущий UI с музыкой и направляющими текстами.
- **PracticeController.swift** — управляет жизненным циклом практики:
  - `startPractice()`/`stopPractice()`;
  - запускает и останавливает таймер heartbeat (раз в 1 секунду);
  - шлёт команды `startWorkout` / `stopWorkout` на часы.
- **PhoneSessionManager.swift** — обёртка над `WCSession` на телефоне (активация сессии и отправка сообщений).

### watchOS

- **PracticeWatchApp.swift** — точка входа watchOS‑приложения, активирует `WatchSessionManager`
  и запрашивает разрешения HealthKit.
- **WatchContentView.swift** — простой экран, который показывает текущий пульс и статус workout‑сессии.
- **WorkoutManager.swift** — обёртка над `HKWorkoutSession` + `HKLiveWorkoutBuilder`:
  - `requestAuthorization()` — запрос разрешений HealthKit;
  - `startWorkout()` — запуск сессии и high‑frequency датчика;
  - `stopWorkout()` — завершение сессии;
  - обновляет `currentHeartRate` при приходе новых данных.
- **WatchSessionManager.swift** — обёртка над `WCSession` на часах:
  - принимает `startWorkout`, `stopWorkout`, `heartbeat` от телефона;
  - запускает/останавливает workout через `WorkoutManager`;
  - следит за таймаутом heartbeat и, если телефон «замолчал», сам завершает workout.

## Как использовать в своём проекте (шаги)

1. **Создай связку iOS App + Watch App в Xcode.**
   - Минимальная версия: iOS 16+/watchOS 9+ (желательно свежее).
   - Добавь Watch App with SwiftUI Interface.

2. **Скопируй файлы из папки `iOS/` в iOS‑target, а файлы из `watchOS/` — в watch‑extension.**

3. **Включи HealthKit для watch‑extension.**
   - В разделе *Signing & Capabilities* добавь capability **HealthKit**.
   - В `Info.plist` watch‑extension добавь строки:
     - `NSHealthShareUsageDescription`
     - `NSHealthUpdateUsageDescription`
     с понятным текстом (например: «Приложению нужен доступ к сердечному ритму для дыхательных практик.»).

4. **Разреши HealthKit на часах при первом запуске.**
   - При старте watch‑приложения вызывается `WorkoutManager.shared.requestAuthorization()` — система покажет пользователю диалог.

5. **Подключи управление практикой на iOS к `PracticeController`.**
   - При старте практики (когда включаешь музыку и текст) вызови:
     `PracticeController.shared.startPractice()`.
   - При завершении/отмене — `PracticeController.shared.stopPractice()`.

6. **Убедись, что музыка и UI практики завязаны на том же состоянии.**
   - В примере есть только комментарии `// TODO:` — туда можно вставить твой текущий код запуска/остановки аудио,
     таймеров и т.д.

7. **Собери и установи связку на устройство.**
   - Сначала на iPhone, затем на Apple Watch (из того же проекта).
   - Убедись, что на iPhone включён Bluetooth и часы сопряжены.

После этого:

- Когда ты нажимаешь «Начать практику» на телефоне:
  - запускается практика (твой контент),
  - на часы уходит `startWorkout`,
  - активируется `HKWorkoutSession`, и пульс начинает приходить чаще.
- Раз в секунду телефон шлёт heartbeat; часы держат сессию активной.
- Если приложение на телефоне уходит в фон или юзер останавливает практику — вызывается `stopPractice()`,
  на часы уходит `stopWorkout` и workout завершается.
- Если телефон внезапно «пропал» (краш, разрядка, потеря связи) — через 5+ секунд без heartbeat
  часы увидят таймаут и сами выключат workout.

Это не «продовый» фреймворк, а **шаблон**, который можно адаптировать под твой текущий проект Amoeba / Breath of Life:
заменить UI, добавить логирование, сохранение сессий и т.д.
