import SwiftUI

struct ContentView: View {
    @EnvironmentObject var practiceController: PracticeController

    var body: some View {
        VStack(spacing: 24) {
            Text(practiceController.isRunning ? "Практика идёт" : "Практика остановлена")
                .font(.title2)

            Text("Состояние отправляется на часы раз в секунду для управления workout-сессией.")
                .font(.footnote)
                .multilineTextAlignment(.center)
                .foregroundColor(.secondary)

            Button(action: togglePractice) {
                Text(practiceController.isRunning ? "Остановить практику" : "Начать практику")
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(practiceController.isRunning ? Color.red : Color.green)
                    .foregroundColor(.white)
                    .cornerRadius(12)
            }
        }
        .padding()
    }

    private func togglePractice() {
        if practiceController.isRunning {
            practiceController.stopPractice()
        } else {
            practiceController.startPractice()
        }
    }
}
