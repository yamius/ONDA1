import Foundation

final class PracticeController: ObservableObject {
    static let shared = PracticeController()

    @Published private(set) var isRunning: Bool = false

    private var heartbeatTimer: Timer?
    private let heartbeatInterval: TimeInterval = 1.0

    private let phoneSession = PhoneSessionManager.shared

    private init() {}

    func startPractice() {
        guard !isRunning else { return }
        isRunning = true

        // TODO: здесь запускаешь музыку, таймер практики, текст и т.д.

        phoneSession.sendCommand(["type": "startWorkout"])
        startHeartbeat()
    }

    func stopPractice() {
        guard isRunning else { return }
        isRunning = false

        stopHeartbeat()
        phoneSession.sendCommand(["type": "stopWorkout"])

        // TODO: здесь останавливаешь музыку, таймер и т.д.
    }

    private func startHeartbeat() {
        heartbeatTimer?.invalidate()
        heartbeatTimer = Timer.scheduledTimer(withTimeInterval: heartbeatInterval,
                                              repeats: true) { [weak self] _ in
            self?.sendHeartbeat()
        }
        if let timer = heartbeatTimer {
            RunLoop.main.add(timer, forMode: .common)
        }
    }

    private func stopHeartbeat() {
        heartbeatTimer?.invalidate()
        heartbeatTimer = nil
    }

    private func sendHeartbeat() {
        guard isRunning else { return }
        phoneSession.sendHeartbeat()
    }
}
