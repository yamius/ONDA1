import SwiftUI
import WatchConnectivity

@main
struct PracticeApp: App {
    @StateObject private var practiceController = PracticeController.shared
    @StateObject private var phoneSessionManager = PhoneSessionManager.shared
    @Environment(\.scenePhase) private var scenePhase

    init() {
        PhoneSessionManager.shared.activate()
    }

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(practiceController)
                .environmentObject(phoneSessionManager)
        }
        .onChange(of: scenePhase) { newPhase in
            if newPhase == .inactive || newPhase == .background {
                // как только приложение уходит из фокуса — останавливаем практику
                PracticeController.shared.stopPractice()
            }
        }
    }
}
