import Foundation
import WatchConnectivity

final class PhoneSessionManager: NSObject, ObservableObject, WCSessionDelegate {
    static let shared = PhoneSessionManager()

    private override init() {
        super.init()
    }

    func activate() {
        guard WCSession.isSupported() else { return }
        let session = WCSession.default
        session.delegate = self
        session.activate()
    }

    // MARK: - Public API

    func sendCommand(_ payload: [String: Any]) {
        sendMessage(payload)
    }

    func sendHeartbeat() {
        let payload: [String: Any] = [
            "type": "heartbeat",
            "ts": Date().timeIntervalSince1970
        ]
        sendMessage(payload)
    }

    // MARK: - Internal

    private func sendMessage(_ payload: [String: Any]) {
        let session = WCSession.default
        guard session.isReachable else {
            // Можно добавить запасной вариант через transferUserInfo, если нужно
            return
        }

        session.sendMessage(payload, replyHandler: nil) { error in
            print("WCSession sendMessage error:", error)
        }
    }

    // MARK: - WCSessionDelegate

    func session(_ session: WCSession,
                 activationDidCompleteWith activationState: WCSessionActivationState,
                 error: Error?) {
        if let error = error {
            print("WCSession activation error:", error)
        } else {
            print("WCSession activated with state:", activationState.rawValue)
        }
    }

    // iOS only
    func sessionDidBecomeInactive(_ session: WCSession) { }

    func sessionDidDeactivate(_ session: WCSession) {
        // После деактивации нужно снова активировать сессию
        session.activate()
    }
}
